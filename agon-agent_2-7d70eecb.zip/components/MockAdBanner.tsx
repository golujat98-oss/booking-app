import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface MockAdBannerProps {
  size?: 'small' | 'large';
  adUnitId?: string;
}

export default function MockAdBanner({ size = 'large', adUnitId }: MockAdBannerProps) {
  return (
    <View style={[styles.banner, size === 'small' && styles.smallBanner]}>
      <View style={styles.adLabel}>
        <Ionicons name="megaphone-outline" size={12} color="#666" />
        <Text style={styles.adText}>ADVERTISEMENT</Text>
      </View>
      <Text style={styles.adContent}>Smart Booking Manager</Text>
      <Text style={styles.adSub}>Book events with ease • Powered by Ads</Text>
      {adUnitId && (
        <Text style={styles.unitId}>ca-app-pub-3927448561170931/9405491657</Text>
      )}
      <TouchableOpacity style={styles.learnMore}>
        <Text style={styles.learnMoreText}>Learn More</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  banner: {
    height: 70,
    backgroundColor: '#f8f9fa',
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 8,
    marginHorizontal: 8,
    borderRadius: 8,
  },
  smallBanner: {
    height: 50,
    marginBottom: 8,
  },
  adLabel: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  adText: {
    fontSize: 10,
    color: '#666',
    fontWeight: '600',
  },
  adContent: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#1f2937',
    marginTop: 2,
  },
  adSub: {
    fontSize: 11,
    color: '#6b7280',
  },
  unitId: {
    fontSize: 9,
    color: '#9ca3af',
    marginTop: 4,
  },
  learnMore: {
    marginTop: 4,
    backgroundColor: '#3b82f6',
    paddingHorizontal: 16,
    paddingVertical: 3,
    borderRadius: 12,
  },
  learnMoreText: {
    color: 'white',
    fontSize: 10,
    fontWeight: '600',
  },
});