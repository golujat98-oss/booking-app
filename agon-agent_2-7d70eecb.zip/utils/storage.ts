import AsyncStorage from '@react-native-async-storage/async-storage';
import { Booking } from '../types';

const BOOKINGS_KEY = 'smart_bookings';

export const storage = {
  async getBookings(): Promise<Booking[]> {
    try {
      const bookings = await AsyncStorage.getItem(BOOKINGS_KEY);
      return bookings ? JSON.parse(bookings) : [];
    } catch (error) {
      console.error('Error getting bookings', error);
      return [];
    }
  },

  async saveBookings(bookings: Booking[]): Promise<void> {
    try {
      await AsyncStorage.setItem(BOOKINGS_KEY, JSON.stringify(bookings));
    } catch (error) {
      console.error('Error saving bookings', error);
    }
  },

  async addBooking(booking: Booking): Promise<void> {
    const bookings = await storage.getBookings();
    bookings.push(booking);
    await storage.saveBookings(bookings);
  },

  async updateBooking(updatedBooking: Booking): Promise<void> {
    const bookings = await storage.getBookings();
    const index = bookings.findIndex(b => b.id === updatedBooking.id);
    if (index !== -1) {
      bookings[index] = updatedBooking;
      await storage.saveBookings(bookings);
    }
  },

  async deleteBooking(id: string): Promise<void> {
    const bookings = await storage.getBookings();
    const filtered = bookings.filter(b => b.id !== id);
    await storage.saveBookings(filtered);
  }
};